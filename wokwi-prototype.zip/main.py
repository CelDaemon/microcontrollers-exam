import time
from machine import Pin
time.sleep(0.1) # Wait for USB to become ready

ACTIVE_TIME = 10 * 1000 # 10 seconds

button_pin = Pin(21, Pin.IN, Pin.PULL_UP)

status_led_pin = Pin(20, Pin.OUT)

strength_led1_pin = Pin(19, Pin.OUT)
strength_led2_pin = Pin(18, Pin.OUT)
strength_led3_pin = Pin(17, Pin.OUT)

trigger_pin = Pin(2, Pin.OUT)
echo_pin = Pin(3, Pin.IN)


activated_time = None


def activate():
    global activated_time
    activated_time = time.ticks_ms()

def is_active():
    global activated_time
    return activated_time and time.ticks_diff(time.ticks_ms(), activated_time) < ACTIVE_TIME

triggered = False
triggered_us = None
distance_mm = None

def get_distance_mm(distance_us):
    return distance_us / 5.8773

def irq(pin):
    global triggered
    global triggered_us
    global distance_mm
    if pin.value():
        triggered_us = time.ticks_us()
    else:
        distance_mm = get_distance_mm(time.ticks_diff(time.ticks_us(), triggered_us))
        triggered = False

echo_pin.irq(handler=irq)

def trigger():
    trigger_pin.value(True)
    time.sleep_us(10)
    trigger_pin.value(False)



def get_strength_index():
    if not distance_mm:
        return 0
    if distance_mm <= 100:
        return 3
    if distance_mm <= 200:
        return 2
    if distance_mm <= 300:
        return 1
    
    return 0


min_distance_mm = None
while True:
    status_led = False
    strength_index = 0
    if not button_pin.value():
        activate()
    if is_active():
        status_led = True
        if not triggered:
            trigger()
        strength_index = get_strength_index()
        if min_distance_mm == None or distance_mm < min_distance_mm:
            min_distance_mm = distance_mm
    elif activated_time:
        print("De opgeslagen afstand is: ", min_distance_mm)
        activated_time = None
        min_distance_mm = None
    status_led_pin.value(status_led)
    strength_led1_pin.value(strength_index > 0)
    strength_led2_pin.value(strength_index > 1)
    strength_led3_pin.value(strength_index > 2)
    time.sleep(0.1)
